# [Cosing Academy - Base Gallery]
A responsive portfolio grid to be used by Coding Academy students


## Usage

### Basic Usage

After downloading, simply edit the HTML, CSS and JS files included with the template to Make-it-Yours.


## Copyright and License

Code released under the [MIT] license.
